# PFE Report — LaTeX source

End-of-studies project report for the MLOps platform. English, engineering
cycle, Scrum (4 sprints).

## Compile on Overleaf (recommended)

1. Zip the **contents** of this `report/` folder (so `main.tex` is at the root of
   the zip), or push to a Git-linked Overleaf project.
2. In Overleaf: **Menu → Settings**
   - **Compiler:** `pdfLaTeX`
   - **TeX Live version:** latest
   - **Main document:** `main.tex`
   - (Bibliography backend is **Biber** by default — leave it.)
3. Click **Recompile twice** (first pass builds the ToC/glossary/labels, second
   resolves them).

## Compile locally

```bash
cd report
latexmk -pdf main.tex      # runs pdflatex + biber + reruns as needed
```
If `latexmk` isn't available: `pdflatex main` → `biber main` → `pdflatex main` →
`pdflatex main`.

## File layout

```
main.tex                 preamble + document assembly (swap class here for school template)
references.bib           bibliography (add entries, cite with \cite{key})
glossary.tex             acronyms (use \gls{key} in text)
frontmatter/             cover, dedication, acknowledgments
chapters/                00 intro · 01–07 body · 08 conclusion
diagrams/                PlantUML sources (.puml) — render to PDF into images/
images/                  all figures (PDF for diagrams, PNG for screenshots)
```

## Rendering the diagrams

The `diagrams/*.puml` files are UML sources. Render each to PDF and drop it in
`images/` with the filename the chapters expect (see `images/.gitkeep`):

- **Easiest:** paste a `.puml` file into <https://www.plantuml.com/plantuml> and
  download the PDF.
- **CLI:** `plantuml -tpdf diagrams/seq_login.puml` then move the PDF to `images/`.
- **VS Code:** the *PlantUML* extension previews + exports.

For the **architecture** figure, prefer redrawing in [draw.io](https://draw.io)
for a polished result (the `.puml` is a faithful starting point).

The chapters currently show **framed placeholders** where figures go; they
compile fine without the images. Replace each placeholder with the
`\includegraphics` line already commented just above it.

## What still needs YOUR input (search the `.tex` files for `>>> USER` and `<<...>>`)

- **INSOMEA** real presentation text + org chart (Chapter 1).
- **Sprint dates** on the Gantt chart (Chapter 3) and **story points** in the
  backlog tables if they differ from the estimates.
- **Burndown** y-values per sprint (Chapters 4–7) — replace with your real data.
- **Screenshots** of the UI for each sprint's "User Interface" section.
- **Cover page** details (school name, diploma, supervisors, jury, year).
- Decide whether an **English abstract + French résumé** are required and whether
  **appendices** are wanted (both easy to add).

## Notes

- Uses only Overleaf-bundled packages (no `minted`, no shell-escape).
- `report` document class with a hand-rolled preamble so it builds with zero
  external files. To use the school's official `.cls`, replace the
  `\documentclass` line in `main.tex` and the cover in `frontmatter/coverpage.tex`;
  everything else stays.
